"""Pydantic schemas."""
